Week 11 Part 2 R tutorial

將整包解壓縮，QMD與CSV留在同一資料夾，用RStudio開啟QMD。
只使用R內建函數，不需安裝額外套件。完整R檔含函數與自行計算對照。
CSV是教學重建資料，不是臨床原始個別資料；兩段CSV不可互換。
